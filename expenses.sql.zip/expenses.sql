-- phpMyAdmin SQL Dump
-- version 4.7.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 01, 2018 at 12:38 PM
-- Server version: 5.6.35
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `expenses`
--

-- --------------------------------------------------------

--
-- Table structure for table `amount`
--

CREATE TABLE `amount` (
  `id` int(10) UNSIGNED NOT NULL,
  `amount` decimal(15,2) DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `amount`
--

INSERT INTO `amount` (`id`, `amount`, `created_at`, `updated_at`, `deleted_at`) VALUES
(21, '946.00', NULL, '2018-02-01 11:28:52', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `balance`
--

CREATE TABLE `balance` (
  `id` int(10) UNSIGNED NOT NULL,
  `before_amount` decimal(15,2) DEFAULT '0.00',
  `entered_amount` decimal(15,2) DEFAULT '0.00',
  `description` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `variance` decimal(15,2) DEFAULT NULL,
  `entry_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `currencies`
--

CREATE TABLE `currencies` (
  `id` int(10) UNSIGNED NOT NULL,
  `cur_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `amount` decimal(15,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `currencies`
--

INSERT INTO `currencies` (`id`, `cur_name`, `amount`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, 'GBP', '0.00', NULL, '2018-02-01 11:28:52', NULL),
(3, 'AUD', '0.00', '2018-01-25 12:47:38', '2018-01-31 14:29:29', NULL),
(4, 'EUR', '0.00', '2018-01-25 12:49:46', '2018-01-31 14:29:44', NULL),
(5, 'CAD', '0.00', '2018-01-25 12:54:36', '2018-01-25 12:54:36', NULL),
(6, 'NGN', '0.00', '2018-01-31 11:59:01', '2018-01-31 11:59:01', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cur_balance`
--

CREATE TABLE `cur_balance` (
  `id` int(10) UNSIGNED NOT NULL,
  `cur_id` int(10) UNSIGNED DEFAULT NULL,
  `entry_date` date DEFAULT NULL,
  `before_amount` decimal(15,2) DEFAULT NULL,
  `entered_amount` decimal(15,2) DEFAULT NULL,
  `description` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `variance` decimal(15,2) DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `id` int(10) UNSIGNED NOT NULL,
  `expenses_category_id` int(10) UNSIGNED DEFAULT NULL,
  `entry_date` date DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `cur_id` int(5) DEFAULT NULL,
  `cur_amount` decimal(15,2) DEFAULT NULL,
  `description` varchar(400) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `expenses_categories`
--

CREATE TABLE `expenses_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `expenses_categories`
--

INSERT INTO `expenses_categories` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Dad', '2018-01-21 20:58:19', '2018-01-21 20:58:19', NULL),
(2, 'Currency Exchange', '2018-01-25 12:59:54', '2018-01-25 12:59:54', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `incomes`
--

CREATE TABLE `incomes` (
  `id` int(10) UNSIGNED NOT NULL,
  `income_category_id` int(10) UNSIGNED DEFAULT NULL,
  `entry_date` date DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `cur_id` int(2) DEFAULT NULL,
  `cur_amount` decimal(15,2) DEFAULT NULL,
  `description` varchar(400) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `incomes_categories`
--

CREATE TABLE `incomes_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `incomes_categories`
--

INSERT INTO `incomes_categories` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Exchange Currency', '2018-01-21 20:58:36', '2018-01-21 20:58:36', NULL),
(2, 'SBI', '2018-02-01 10:58:13', '2018-02-01 10:58:13', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_10_12_100000_create_password_resets_table', 1),
('2016_11_08_085948_create_roles_table', 1),
('2016_11_08_085949_create_users_table', 1),
('2016_11_08_085950_create_user_actions_table', 1),
('2016_11_08_091826_create_expenses_categories_table', 1),
('2016_11_08_092200_create_expenses_table', 1),
('2016_11_08_092653_create_incomes_categories_table', 1),
('2016_11_08_093112_create_incomes_table', 1),
('2018_01_18_182935_create_balance', 1),
('2018_01_23_135310_create_currencies_table', 2),
('2018_01_26_114739_create_cur_balance_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `title`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Administrator (can create other users)', '2018-01-21 20:56:30', '2018-01-21 20:56:30', NULL),
(2, 'Simple user', '2018-01-21 20:56:30', '2018-01-21 20:56:30', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `role_id` int(10) UNSIGNED DEFAULT NULL,
  `remember_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role_id`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Admin', 'admin@admin.com', '$2y$10$yjnRY5EyfwLWJrsez36B2uzOrTgP2U0DKYOX53MiOkOWNJUSmL13q', 1, NULL, '2018-01-21 20:56:30', '2018-01-21 20:56:30', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_actions`
--

CREATE TABLE `user_actions` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `action` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `action_model` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `action_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_actions`
--

INSERT INTO `user_actions` (`id`, `user_id`, `action`, `action_model`, `action_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 'created', 'expenses_categories', 1, '2018-01-21 20:58:19', '2018-01-21 20:58:19', NULL),
(2, 1, 'created', 'incomes_categories', 1, '2018-01-21 20:58:37', '2018-01-21 20:58:37', NULL),
(3, 1, 'created', 'incomes', 1, '2018-01-21 20:59:15', '2018-01-21 20:59:15', NULL),
(4, 1, 'created', 'expenses', 1, '2018-01-21 21:00:06', '2018-01-21 21:00:06', NULL),
(5, 1, 'created', 'balance', 1, '2018-01-22 11:29:05', '2018-01-22 11:29:05', NULL),
(6, 1, 'updated', 'incomes', 1, '2018-01-22 12:10:26', '2018-01-22 12:10:26', NULL),
(7, 1, 'updated', 'expenses', 1, '2018-01-22 12:10:33', '2018-01-22 12:10:33', NULL),
(8, 1, 'created', 'balance', 4, '2018-01-22 12:25:34', '2018-01-22 12:25:34', NULL),
(9, 1, 'created', 'balance', 5, '2018-01-22 12:26:59', '2018-01-22 12:26:59', NULL),
(10, 1, 'created', 'balance', 6, '2018-01-22 12:28:31', '2018-01-22 12:28:31', NULL),
(11, 1, 'created', 'balance', 7, '2018-01-22 12:29:25', '2018-01-22 12:29:25', NULL),
(12, 1, 'created', 'balance', 8, '2018-01-22 12:30:21', '2018-01-22 12:30:21', NULL),
(13, 1, 'created', 'balance', 9, '2018-01-22 12:31:07', '2018-01-22 12:31:07', NULL),
(14, 1, 'created', 'balance', 10, '2018-01-22 12:32:19', '2018-01-22 12:32:19', NULL),
(15, 1, 'created', 'balance', 11, '2018-01-22 12:33:43', '2018-01-22 12:33:43', NULL),
(16, 1, 'created', 'balance', 12, '2018-01-22 12:35:06', '2018-01-22 12:35:06', NULL),
(17, 1, 'created', 'balance', 13, '2018-01-22 12:35:27', '2018-01-22 12:35:27', NULL),
(18, 1, 'created', 'balance', 14, '2018-01-22 12:35:41', '2018-01-22 12:35:41', NULL),
(19, 1, 'created', 'balance', 15, '2018-01-22 12:36:00', '2018-01-22 12:36:00', NULL),
(20, 1, 'created', 'balance', 16, '2018-01-22 12:36:26', '2018-01-22 12:36:26', NULL),
(21, 1, 'created', 'incomes', 2, '2018-01-22 12:39:01', '2018-01-22 12:39:01', NULL),
(22, 1, 'created', 'balance', 17, '2018-01-22 12:39:15', '2018-01-22 12:39:15', NULL),
(23, 1, 'created', 'balance', 18, '2018-01-22 12:42:11', '2018-01-22 12:42:11', NULL),
(24, 1, 'created', 'balance', 19, '2018-01-22 12:46:36', '2018-01-22 12:46:36', NULL),
(25, 1, 'created', 'balance', 20, '2018-01-22 13:11:12', '2018-01-22 13:11:12', NULL),
(26, 1, 'created', 'balance', 21, '2018-01-22 13:33:09', '2018-01-22 13:33:09', NULL),
(27, 1, 'created', 'balance', 22, '2018-01-22 13:40:06', '2018-01-22 13:40:06', NULL),
(28, 1, 'created', 'balance', 23, '2018-01-22 13:47:38', '2018-01-22 13:47:38', NULL),
(29, 1, 'created', 'balance', 24, '2018-01-22 13:48:18', '2018-01-22 13:48:18', NULL),
(30, 1, 'created', 'balance', 25, '2018-01-22 13:49:21', '2018-01-22 13:49:21', NULL),
(31, 1, 'created', 'balance', 26, '2018-01-22 13:50:04', '2018-01-22 13:50:04', NULL),
(32, 1, 'created', 'balance', 27, '2018-01-22 13:52:56', '2018-01-22 13:52:56', NULL),
(33, 1, 'created', 'balance', 28, '2018-01-22 13:54:02', '2018-01-22 13:54:02', NULL),
(34, 1, 'created', 'balance', 29, '2018-01-22 13:54:56', '2018-01-22 13:54:56', NULL),
(35, 1, 'created', 'balance', 30, '2018-01-22 13:56:23', '2018-01-22 13:56:23', NULL),
(36, 1, 'created', 'balance', 31, '2018-01-22 14:23:09', '2018-01-22 14:23:09', NULL),
(37, 1, 'created', 'balance', 32, '2018-01-22 14:23:50', '2018-01-22 14:23:50', NULL),
(38, 1, 'created', 'balance', 33, '2018-01-22 14:24:25', '2018-01-22 14:24:25', NULL),
(39, 1, 'created', 'balance', 34, '2018-01-22 14:25:03', '2018-01-22 14:25:03', NULL),
(40, 1, 'created', 'balance', 35, '2018-01-22 14:25:19', '2018-01-22 14:25:19', NULL),
(41, 1, 'created', 'balance', 36, '2018-01-22 14:25:39', '2018-01-22 14:25:39', NULL),
(42, 1, 'created', 'balance', 1, '2018-01-23 09:32:12', '2018-01-23 09:32:12', NULL),
(43, 1, 'created', 'balance', 2, '2018-01-23 10:07:27', '2018-01-23 10:07:27', NULL),
(44, 1, 'updated', 'balance', 2, '2018-01-23 10:15:18', '2018-01-23 10:15:18', NULL),
(45, 1, 'updated', 'balance', 2, '2018-01-23 10:15:51', '2018-01-23 10:15:51', NULL),
(46, 1, 'created', 'balance', 4, '2018-01-23 11:05:47', '2018-01-23 11:05:47', NULL),
(47, 1, 'created', 'balance', 5, '2018-01-23 11:19:10', '2018-01-23 11:19:10', NULL),
(48, 1, 'created', 'balance', 6, '2018-01-23 11:22:52', '2018-01-23 11:22:52', NULL),
(49, 1, 'created', 'balance', 8, '2018-01-23 11:28:25', '2018-01-23 11:28:25', NULL),
(50, 1, 'created', 'balance', 9, '2018-01-23 11:30:15', '2018-01-23 11:30:15', NULL),
(51, 1, 'created', 'balance', 10, '2018-01-23 11:30:40', '2018-01-23 11:30:40', NULL),
(52, 1, 'created', 'balance', 11, '2018-01-23 11:31:10', '2018-01-23 11:31:10', NULL),
(53, 1, 'created', 'balance', 12, '2018-01-23 11:32:41', '2018-01-23 11:32:41', NULL),
(54, 1, 'created', 'balance', 13, '2018-01-23 11:33:02', '2018-01-23 11:33:02', NULL),
(55, 1, 'updated', 'balance', 13, '2018-01-23 11:33:51', '2018-01-23 11:33:51', NULL),
(56, 1, 'updated', 'balance', 13, '2018-01-23 11:34:32', '2018-01-23 11:34:32', NULL),
(57, 1, 'updated', 'balance', 13, '2018-01-23 11:34:45', '2018-01-23 11:34:45', NULL),
(58, 1, 'updated', 'balance', 13, '2018-01-23 11:35:11', '2018-01-23 11:35:11', NULL),
(59, 1, 'created', 'balance', 14, '2018-01-25 11:11:46', '2018-01-25 11:11:46', NULL),
(60, 1, 'created', 'expenses_categories', 2, '2018-01-25 12:59:54', '2018-01-25 12:59:54', NULL),
(61, 1, 'created', 'incomes', 3, '2018-01-25 14:20:24', '2018-01-25 14:20:24', NULL),
(62, 1, 'created', 'expenses', 2, '2018-01-26 11:21:03', '2018-01-26 11:21:03', NULL),
(63, 1, 'created', 'expenses', 3, '2018-01-26 11:22:50', '2018-01-26 11:22:50', NULL),
(64, 1, 'created', 'incomes', 4, '2018-01-26 11:32:12', '2018-01-26 11:32:12', NULL),
(65, 1, 'created', 'balance', 15, '2018-01-26 11:58:04', '2018-01-26 11:58:04', NULL),
(66, 1, 'created', 'incomes', 5, '2018-01-26 12:02:18', '2018-01-26 12:02:18', NULL),
(67, 1, 'created', 'incomes', 6, '2018-01-26 14:08:11', '2018-01-26 14:08:11', NULL),
(68, 1, 'created', 'incomes', 7, '2018-01-26 14:28:12', '2018-01-26 14:28:12', NULL),
(69, 1, 'created', 'expenses', 4, '2018-01-26 14:28:35', '2018-01-26 14:28:35', NULL),
(70, 1, 'created', 'balance', 16, '2018-01-26 14:31:50', '2018-01-26 14:31:50', NULL),
(71, 1, 'created', 'balance', 17, '2018-01-27 04:58:09', '2018-01-27 04:58:09', NULL),
(72, 1, 'created', 'incomes', 8, '2018-01-27 05:00:34', '2018-01-27 05:00:34', NULL),
(73, 1, 'created', 'incomes', 9, '2018-01-27 05:01:06', '2018-01-27 05:01:06', NULL),
(74, 1, 'created', 'incomes', 10, '2018-01-27 05:01:56', '2018-01-27 05:01:56', NULL),
(75, 1, 'created', 'incomes', 11, '2018-01-27 05:02:18', '2018-01-27 05:02:18', NULL),
(76, 1, 'created', 'balance', 18, '2018-01-29 11:08:53', '2018-01-29 11:08:53', NULL),
(77, 1, 'created', 'incomes', 12, '2018-01-29 11:19:55', '2018-01-29 11:19:55', NULL),
(78, 1, 'created', 'incomes', 13, '2018-01-29 11:23:20', '2018-01-29 11:23:20', NULL),
(79, 1, 'created', 'incomes', 14, '2018-01-29 11:24:34', '2018-01-29 11:24:34', NULL),
(80, 1, 'created', 'incomes', 15, '2018-01-29 11:26:28', '2018-01-29 11:26:28', NULL),
(81, 1, 'created', 'incomes', 16, '2018-01-29 11:28:02', '2018-01-29 11:28:02', NULL),
(82, 1, 'created', 'incomes', 17, '2018-01-29 11:36:22', '2018-01-29 11:36:22', NULL),
(83, 1, 'created', 'incomes', 18, '2018-01-29 11:37:31', '2018-01-29 11:37:31', NULL),
(84, 1, 'created', 'incomes', 19, '2018-01-29 11:39:18', '2018-01-29 11:39:18', NULL),
(85, 1, 'created', 'incomes', 20, '2018-01-29 11:42:07', '2018-01-29 11:42:07', NULL),
(86, 1, 'created', 'incomes', 21, '2018-01-29 11:42:53', '2018-01-29 11:42:53', NULL),
(87, 1, 'created', 'incomes', 22, '2018-01-29 11:43:23', '2018-01-29 11:43:23', NULL),
(88, 1, 'created', 'incomes', 23, '2018-01-29 11:46:01', '2018-01-29 11:46:01', NULL),
(89, 1, 'created', 'incomes', 24, '2018-01-29 11:46:22', '2018-01-29 11:46:22', NULL),
(90, 1, 'created', 'incomes', 25, '2018-01-29 12:00:43', '2018-01-29 12:00:43', NULL),
(91, 1, 'created', 'incomes', 26, '2018-01-29 12:01:03', '2018-01-29 12:01:03', NULL),
(92, 1, 'created', 'incomes', 27, '2018-01-29 12:01:38', '2018-01-29 12:01:38', NULL),
(93, 1, 'created', 'incomes', 28, '2018-01-29 12:02:26', '2018-01-29 12:02:26', NULL),
(94, 1, 'created', 'incomes', 29, '2018-01-29 12:03:39', '2018-01-29 12:03:39', NULL),
(95, 1, 'created', 'incomes', 30, '2018-01-29 12:03:57', '2018-01-29 12:03:57', NULL),
(96, 1, 'created', 'incomes', 31, '2018-01-29 12:04:21', '2018-01-29 12:04:21', NULL),
(97, 1, 'created', 'incomes', 32, '2018-01-29 12:05:45', '2018-01-29 12:05:45', NULL),
(98, 1, 'created', 'incomes', 33, '2018-01-29 12:05:54', '2018-01-29 12:05:54', NULL),
(99, 1, 'created', 'incomes', 34, '2018-01-29 12:06:56', '2018-01-29 12:06:56', NULL),
(100, 1, 'created', 'incomes', 35, '2018-01-29 12:19:20', '2018-01-29 12:19:20', NULL),
(101, 1, 'created', 'incomes', 36, '2018-01-29 12:20:59', '2018-01-29 12:20:59', NULL),
(102, 1, 'created', 'incomes', 37, '2018-01-29 12:24:35', '2018-01-29 12:24:35', NULL),
(103, 1, 'created', 'expenses', 1, '2018-01-29 12:37:36', '2018-01-29 12:37:36', NULL),
(104, 1, 'created', 'expenses', 2, '2018-01-29 12:37:53', '2018-01-29 12:37:53', NULL),
(105, 1, 'created', 'expenses', 3, '2018-01-29 12:57:36', '2018-01-29 12:57:36', NULL),
(106, 1, 'created', 'expenses', 4, '2018-01-29 12:58:27', '2018-01-29 12:58:27', NULL),
(107, 1, 'created', 'expenses', 5, '2018-01-29 12:59:39', '2018-01-29 12:59:39', NULL),
(108, 1, 'created', 'incomes', 38, '2018-01-29 13:00:29', '2018-01-29 13:00:29', NULL),
(109, 1, 'created', 'expenses', 6, '2018-01-29 13:00:59', '2018-01-29 13:00:59', NULL),
(110, 1, 'created', 'balance', 19, '2018-01-29 13:42:09', '2018-01-29 13:42:09', NULL),
(111, 1, 'created', 'balance', 20, '2018-01-29 21:23:26', '2018-01-29 21:23:26', NULL),
(112, 1, 'created', 'incomes', 39, '2018-01-30 13:05:34', '2018-01-30 13:05:34', NULL),
(113, 1, 'created', 'incomes', 40, '2018-01-30 13:06:37', '2018-01-30 13:06:37', NULL),
(114, 1, 'created', 'incomes', 41, '2018-01-30 13:06:51', '2018-01-30 13:06:51', NULL),
(115, 1, 'created', 'incomes', 42, '2018-01-30 13:08:41', '2018-01-30 13:08:41', NULL),
(116, 1, 'created', 'incomes', 43, '2018-01-30 13:10:01', '2018-01-30 13:10:01', NULL),
(117, 1, 'created', 'balance', 21, '2018-01-31 11:50:10', '2018-01-31 11:50:10', NULL),
(118, 1, 'created', 'expenses', 1, '2018-01-31 12:00:59', '2018-01-31 12:00:59', NULL),
(119, 1, 'created', 'balance', 23, '2018-01-31 13:31:26', '2018-01-31 13:31:26', NULL),
(120, 1, 'created', 'balance', 24, '2018-01-31 13:47:21', '2018-01-31 13:47:21', NULL),
(121, 1, 'created', 'balance', 25, '2018-01-31 13:47:40', '2018-01-31 13:47:40', NULL),
(122, 1, 'created', 'expenses', 2, '2018-01-31 15:41:28', '2018-01-31 15:41:28', NULL),
(123, 1, 'created', 'expenses', 3, '2018-01-31 16:10:09', '2018-01-31 16:10:09', NULL),
(124, 1, 'created', 'expenses', 4, '2018-01-31 20:46:01', '2018-01-31 20:46:01', NULL),
(125, 1, 'created', 'expenses', 5, '2018-01-31 20:53:13', '2018-01-31 20:53:13', NULL),
(126, 1, 'created', 'expenses', 6, '2018-01-31 20:56:26', '2018-01-31 20:56:26', NULL),
(127, 1, 'created', 'expenses', 7, '2018-01-31 20:57:22', '2018-01-31 20:57:22', NULL),
(128, 1, 'created', 'expenses', 8, '2018-01-31 20:59:19', '2018-01-31 20:59:19', NULL),
(129, 1, 'created', 'expenses', 9, '2018-01-31 21:01:32', '2018-01-31 21:01:32', NULL),
(130, 1, 'created', 'expenses', 10, '2018-01-31 21:06:06', '2018-01-31 21:06:06', NULL),
(131, 1, 'created', 'expenses', 11, '2018-01-31 21:06:21', '2018-01-31 21:06:21', NULL),
(132, 1, 'created', 'expenses', 12, '2018-01-31 21:06:30', '2018-01-31 21:06:30', NULL),
(133, 1, 'created', 'expenses', 13, '2018-01-31 21:06:52', '2018-01-31 21:06:52', NULL),
(134, 1, 'created', 'expenses', 14, '2018-02-01 10:30:01', '2018-02-01 10:30:01', NULL),
(135, 1, 'created', 'expenses', 15, '2018-02-01 10:30:44', '2018-02-01 10:30:44', NULL),
(136, 1, 'created', 'expenses', 16, '2018-02-01 10:31:40', '2018-02-01 10:31:40', NULL),
(137, 1, 'created', 'expenses', 17, '2018-02-01 10:32:31', '2018-02-01 10:32:31', NULL),
(138, 1, 'created', 'expenses', 18, '2018-02-01 10:32:53', '2018-02-01 10:32:53', NULL),
(139, 1, 'created', 'expenses', 19, '2018-02-01 10:44:02', '2018-02-01 10:44:02', NULL),
(140, 1, 'created', 'expenses', 20, '2018-02-01 10:44:46', '2018-02-01 10:44:46', NULL),
(141, 1, 'created', 'expenses', 21, '2018-02-01 10:45:37', '2018-02-01 10:45:37', NULL),
(142, 1, 'created', 'expenses', 22, '2018-02-01 10:49:56', '2018-02-01 10:49:56', NULL),
(143, 1, 'created', 'expenses', 23, '2018-02-01 10:51:35', '2018-02-01 10:51:35', NULL),
(144, 1, 'created', 'expenses', 24, '2018-02-01 10:52:47', '2018-02-01 10:52:47', NULL),
(145, 1, 'created', 'incomes_categories', 2, '2018-02-01 10:58:13', '2018-02-01 10:58:13', NULL),
(146, 1, 'created', 'incomes', 44, '2018-02-01 11:27:57', '2018-02-01 11:27:57', NULL),
(147, 1, 'created', 'incomes', 45, '2018-02-01 11:28:52', '2018-02-01 11:28:52', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `amount`
--
ALTER TABLE `amount`
  ADD PRIMARY KEY (`id`),
  ADD KEY `balance_deleted_at_index` (`deleted_at`);

--
-- Indexes for table `balance`
--
ALTER TABLE `balance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `balance_deleted_at_index` (`deleted_at`);

--
-- Indexes for table `currencies`
--
ALTER TABLE `currencies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `currencies_deleted_at_index` (`deleted_at`);

--
-- Indexes for table `cur_balance`
--
ALTER TABLE `cur_balance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cur_balance_deleted_at_index` (`deleted_at`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_71_expensescategory_expenses_category_id_expense` (`expenses_category_id`),
  ADD KEY `expenses_deleted_at_index` (`deleted_at`);

--
-- Indexes for table `expenses_categories`
--
ALTER TABLE `expenses_categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `expenses_categories_deleted_at_index` (`deleted_at`);

--
-- Indexes for table `incomes`
--
ALTER TABLE `incomes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_73_incomescategory_income_category_id_income` (`income_category_id`),
  ADD KEY `incomes_deleted_at_index` (`deleted_at`);

--
-- Indexes for table `incomes_categories`
--
ALTER TABLE `incomes_categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `incomes_categories_deleted_at_index` (`deleted_at`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`),
  ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `roles_deleted_at_index` (`deleted_at`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_68_role_role_id_user` (`role_id`),
  ADD KEY `users_deleted_at_index` (`deleted_at`);

--
-- Indexes for table `user_actions`
--
ALTER TABLE `user_actions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_69_user_user_id_user_action` (`user_id`),
  ADD KEY `user_actions_deleted_at_index` (`deleted_at`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `amount`
--
ALTER TABLE `amount`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `balance`
--
ALTER TABLE `balance`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `currencies`
--
ALTER TABLE `currencies`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `cur_balance`
--
ALTER TABLE `cur_balance`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `expenses_categories`
--
ALTER TABLE `expenses_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `incomes`
--
ALTER TABLE `incomes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;
--
-- AUTO_INCREMENT for table `incomes_categories`
--
ALTER TABLE `incomes_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `user_actions`
--
ALTER TABLE `user_actions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=148;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `expenses`
--
ALTER TABLE `expenses`
  ADD CONSTRAINT `fk_71_expensescategory_expenses_category_id_expense` FOREIGN KEY (`expenses_category_id`) REFERENCES `expenses_categories` (`id`);

--
-- Constraints for table `incomes`
--
ALTER TABLE `incomes`
  ADD CONSTRAINT `fk_73_incomescategory_income_category_id_income` FOREIGN KEY (`income_category_id`) REFERENCES `incomes_categories` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_68_role_role_id_user` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);

--
-- Constraints for table `user_actions`
--
ALTER TABLE `user_actions`
  ADD CONSTRAINT `fk_69_user_user_id_user_action` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
